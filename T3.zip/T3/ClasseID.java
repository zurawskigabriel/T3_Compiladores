public enum ClasseID {
  TipoBase,
  VarGlobal,
  NomeFuncao,
  NomeParam,
  VarLocal,
  NomeStruct,
  CampoStruct;
}

